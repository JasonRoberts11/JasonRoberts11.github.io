public class HelloWorld {
	/**This is a comment
	So is this
	**/
	public static void main(String[] args){
		System.out.println("Hello, World!!!!!!");
	}
}